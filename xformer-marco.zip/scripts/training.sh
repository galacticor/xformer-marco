#/bin/bash

nohup python main.py longformer &
